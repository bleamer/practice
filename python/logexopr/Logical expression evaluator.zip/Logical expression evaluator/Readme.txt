Logical Expression Evaluator : Reads user data from data.json and evaluates logical expression in opdat.json and prints the result


How to run:
Please ensure Python 3.0 or higher is installed.
Please ensure data.json and opdat.json are stored in the same folder as logExEvaluator.py

The script can be executed from terminal using the following command:
python logExEvaluator.py




The file in the folder:

data.json : Example user data on which logical expressions will be evaluated, stored in JSON format
opdat.json : File to store logical expressions, in JSON format
logExEvaluator.py : python script to evaluate logical expressions and print the Boolean(result)
